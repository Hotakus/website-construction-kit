#include <stdint.h>
#include <sys/types.h>
typedef uint32_t crypto_uint32;

#define select ed25519_select
